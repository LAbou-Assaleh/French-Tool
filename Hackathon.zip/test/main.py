from pygame import *
import pygame
import sys
import openai
import creds
from verbecc import Conjugator
from deep_translator import GoogleTranslator

openai.api_key = creds.api
cg = Conjugator(lang='fr')
init()
SIZE = (800, 500)
screen = display.set_mode(SIZE)
screenrect = (0, 0, 800, 500)
# -----COLORS-----
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (100, 100, 100)
YELLOW = (255, 193, 37)
moodyBlue = (28, 134, 238)
lightMoodyBlue = (0, 178, 238)
cornBlue = (0, 154, 205)
darkPink = (205, 16, 118)
BEIGE = (245, 245, 220)
# -----FONTS-----
myFont = font.SysFont('Times New Roman', 30)
font = font.SysFont("Times New Roman", 20)


# -----FUNCTIONS-----


def Conjugaison(verb, tense):
  baseverb = openai.Completion.create(
    model="text-davinci-003",
    prompt=f" la forme infinitive de {verb} est",
    temperature=0,
    max_tokens=150,
    top_p=1,
    frequency_penalty=0.0,
    presence_penalty=0.6,
    stop=["."]
  )
  verb = baseverb.choices[0].text
  verb = verb.strip()
  conjugation = cg.conjugate(verb)
  changed = conjugation['moods']['indicatif'][tense]
  response = openai.Completion.create(
    model="text-davinci-003",
    prompt=f"an example of a sentance using the french verb {verb} in {tense} is",
    temperature=0,
    max_tokens=500,
    top_p=0,
    frequency_penalty=0.0,
    presence_penalty=0.6,
    stop=["."]
  )
  response = response.choices[0].text
  response = response.strip()
  tresponse = GoogleTranslator(source='fr', target='en').translate(response)
  return response, verb, changed, tresponse


def define(noun):
  translated = GoogleTranslator(source='fr', target='en').translate(noun)
  return translated


def letter():
  while True:
    for event in pygame.event.get():
      if event.type == KEYUP:
        if event.key == K_0:
          return "0"
        elif event.key == K_1:
          return "1"
        elif event.key == K_2:
          return "2"
        elif event.key == K_3:
          return "3"
        elif event.key == K_4:
          return "4"
        elif event.key == K_5:
          return "5"
        elif event.key == K_6:
          return "6"
        elif event.key == K_7:
          return "7"
        elif event.key == K_8:
          return "8"
        elif event.key == K_9:
          return "9"
        elif event.key == K_a:
          return "a"
        elif event.key == K_b:
          return "b"
        elif event.key == K_c:
          return "c"
        elif event.key == K_d:
          return "d"
        elif event.key == K_e:
          return "e"
        elif event.key == K_f:
          return "f"
        elif event.key == K_g:
          return "g"
        elif event.key == K_h:
          return "h"
        elif event.key == K_i:
          return "i"
        elif event.key == K_j:
          return "j"
        elif event.key == K_k:
          return "k"
        elif event.key == K_l:
          return "l"
        elif event.key == K_m:
          return "m"
        elif event.key == K_n:
          return "n"
        elif event.key == K_o:
          return "o"
        elif event.key == K_p:
          return "p"
        elif event.key == K_q:
          return "q"
        elif event.key == K_r:
          return "r"
        elif event.key == K_s:
          return "s"
        elif event.key == K_t:
          return "t"
        elif event.key == K_u:
          return "u"
        elif event.key == K_v:
          return "v"
        elif event.key == K_w:
          return "w"
        elif event.key == K_x:
          return "x"
        elif event.key == K_y:
          return "y"
        elif event.key == K_z:
          return "z"
        elif event.key == K_COMMA:
          return ","
        elif event.key == K_SPACE:
          return " "
        elif event.key == K_BACKSPACE:
          return "delete"
        elif event.key == K_RETURN:
          return "check"
        else:
          return "Invalid"


def xCenteredText(string, size, rect, color, y):
  font = pygame.font.SysFont("Times New Roman", size)
  textWidth, textHeight = font.size(string)
  centerx = (rect[2] - textWidth) // 2
  text = font.render(string, 1, color)
  screen.blit(text, [centerx, y])


def centertext(string, size, rect):
  font = pygame.font.SysFont("Times New Roman", size)
  textWidth, textHeight = font.size(string)
  centerx = (rect[2] - textWidth) // 2
  centery = (rect[2] - textHeight) // 2
  text = font.render(string, 1, BLACK)
  screen.blit(text, [centerx, centery])


def drawtext(string, size, rect, color, x, y):
  font = pygame.font.SysFont("Times New Roman", size)
  textWidth, textHeight = font.size(string)
  textRect = Rect(x, y, textWidth, textHeight)
  text = font.render(string, 1, color)
  screen.blit(text, textRect)
  pygame.display.update()


def homescreen(mx, my, button, currentState):
  screen.fill(WHITE)
  # title
  xCenteredText('Google translate', 50, screenrect, (0, 0, 0), 50)
  draw.line(screen, BLACK, (180, 80), (370, 80), 5)
  drawtext('Hackathon', 40, screenrect, BLUE, 180, 20)
  # the box for the inputs
  nounBox = Rect(225, 225, 100, 50)
  draw.rect(screen, BLACK, nounBox, 3)
  verbBox = Rect(375, 225, 100, 50)
  draw.rect(screen, BLACK, verbBox, 3)
  verbB = myFont.render("Verb", 1, BLACK)
  screen.blit(verbB, (380, 230))
  verbB = myFont.render("Noun", 1, BLACK)
  screen.blit(verbB, (230, 230))
  if nounBox.collidepoint(mx, my) == True:
    draw.rect(screen, YELLOW, nounBox)
    draw.rect(screen, BLACK, nounBox, 3)
    verbB = myFont.render("Noun", 1, BLACK)
    screen.blit(verbB, (230, 230))
    if button == 1:
      currentState = STATE_NOUN
  if verbBox.collidepoint(mx, my) == True:
    draw.rect(screen, YELLOW, verbBox)
    draw.rect(screen, BLACK, verbBox, 3)
    verbB = myFont.render("Verb", 1, BLACK)
    screen.blit(verbB, (380, 230))
    if button == 1:
      currentState = STATE_VERB
  return currentState


# search screen function
def backButton(mx, my, button):
  draw.rect(screen, BLACK, (10, 10, 106, 46))
  draw.rect(screen, WHITE, (13, 13, 100, 40))
  draw.rect(screen, BLACK, (43, 25, 58, 14))
  draw.polygon(screen, BLACK, ((23, 32), (43, 16), (43, 49)))
  area = Rect(10, 10, 106, 46)
  if area.collidepoint(mx, my) == True:
    draw.rect(screen, BLACK, (10, 10, 106, 46))
    draw.rect(screen, YELLOW, (13, 13, 100, 40))
    draw.rect(screen, BLACK, (43, 25, 58, 14))
    draw.polygon(screen, BLACK, ((23, 32), (43, 16), (43, 49)))
    if button == 1:
      return True
  return False


def nounscreen(mx, my, button, currentState):
  global noun, translated
  screen.fill(WHITE)
  draw.rect(screen, BLACK, searchBox, 3)
  draw.rect(screen, BLUE, enterBox)
  if backButton(mx, my, button) == True:
    noun = ""
    translated = ""
    currentState = STATE_MAIN
  return currentState


def verbscreen(mx, my, button, currentState):
  global verb, verbtranslated
  screen.fill(WHITE)
  draw.rect(screen, BLACK, searchBox, 3)
  draw.rect(screen, BLUE, enterBox)
  if backButton(mx, my, button) == True:
    verb = ""
    verbtranslated = ""
    currentState = STATE_MAIN
  return currentState


def tense_menu():
  screen.fill(WHITE)
  button = 0
  while True:
    for evnt in event.get():
      if evnt.type == QUIT:
        running = False
      if evnt.type == MOUSEBUTTONDOWN:
        button = evnt.button
    mx, my = pygame.mouse.get_pos()
    draw.rect(screen, BLACK, searchBox, 3)
    draw.rect(screen, BLUE, enterBox)
    tenseList = ["Passé Antérieur", "Futur Antérieur", "Plus que Parfait", "Passé Composé", 'Passé Simple',
                 "Futur Simple", "Imparfait", "Présent"]
    tenselist = ["passé-antérieur", "futur-antérieur", "plus-que-parfait", "passé-composé", 'passé-simple',
                 "futur-simple", "imparfait", "présent"]
    widthX = 800 // 5
    heightY = 500 // 27
    startY = heightY + 50
    screen.fill(WHITE)
    print(mx, my)
    for i in range(8):
      currentRect = pygame.Rect(widthX, startY, 3 * widthX, 2 * heightY)
      if currentRect.collidepoint(mx, my) == True:
        pygame.draw.rect(screen, (255, 0, 0), currentRect)
        if button == 1:
          tense = tenselist[i]
          return tense
      else:
        pygame.draw.rect(screen, (0, 100, 255), currentRect)
      # centertext(tenseList[i], 40, rect)
      xCenteredText(tenseList[i], 31, screenrect, (0, 0, 0), startY)
      startY += 3 * heightY
    pygame.display.update()


# -----STATES-----
STATE_MAIN = 0
STATE_EXIT = 1
STATE_NOUN = 2
STATE_VERB = 3
STATE_TENSE = 4

# -----SETUP-----
running = True
myClock = time.Clock()
currentState = STATE_MAIN
mx = my = button = 0
search_rect = pygame.Rect(50, 25, 400, 50)
search_font = pygame.font.Font(None, 36)
search_text = ""
cursor_pos = 0
cursor_blink_timer = 0
text = ""
cursor_on = True
cursor_timer = 0
text_surface = font.render(text, True, (0, 0, 0))
noun = ""
verb = ""
translated = ""
verbtranslated = ""
searchBox = Rect(200, 100, 300, 50)
enterBox = Rect(505, 100, 50, 50)
tense = "imparfait"
go = False
# -----RUN LOOP-----
while running:
  for evnt in event.get():
    if evnt.type == QUIT:
      running = False
    if evnt.type == MOUSEBUTTONDOWN:
      mx, my = evnt.pos
      button = evnt.button
    if evnt.type == MOUSEMOTION:
      mx, my = evnt.pos
    if enterBox.collidepoint(mx, my) and button == 1:
      if currentState == STATE_NOUN:
        noun = search_text.lower()
      else:
        verb = search_text.lower()
      if noun != "":
        translated = define(noun)
      if verb != "":
        tense = ""
        response, verb, changed, tresponse = Conjugaison(verb, tense)
        go = True
      search_text = ""
      cursor_pos = 0
    elif evnt.type == KEYDOWN:
      if evnt.key == pygame.K_BACKSPACE:
        text = text[:-1]
        if cursor_pos > 0:
          search_text = search_text[:cursor_pos - 1] + search_text[cursor_pos:]
          cursor_pos -= 1
      elif evnt.key == pygame.K_RETURN:
        if currentState == STATE_NOUN:
          noun = search_text.lower()
        else:
          verb = search_text.lower()
        if noun != "":
          translated = define(noun)
        if verb != "":
          tense = ""
          while tense == "":
            tense = tense_menu()
          response, verb, changed, tresponse = Conjugaison(verb, tense)
          go = True
        search_text = ""
        cursor_pos = 0
      elif evnt.key == pygame.K_RIGHT:
        if cursor_pos < len(search_text):
          cursor_pos += 1
      elif evnt.key == pygame.K_LEFT:
        if cursor_pos > 0:
          cursor_pos -= 1
      else:
        search_text = search_text[:cursor_pos] + evnt.unicode + search_text[cursor_pos:]
        cursor_pos += 1
        text += evnt.unicode
        button = 0

    if currentState == STATE_MAIN:
      currentState = homescreen(mx, my, button, currentState)

    elif currentState == STATE_NOUN:
      currentState = nounscreen(mx, my, button, currentState)
      # blitting text onto screen
      text_surface = search_font.render(search_text, True, BLACK)
      screen.blit(text_surface, (210, 115))
      drawtext(translated, 20, screenrect, BLACK, 200, 170)
    elif currentState == STATE_VERB:
      currentState = verbscreen(mx, my, button, currentState)
      # blitting text onto screen
      text_surface = search_font.render(search_text, True, BLACK)
      screen.blit(text_surface, (210, 115))
      if go:
        drawtext(verb, 20, screenrect, BLACK, 200, 180)
        drawtext(changed[0], 20, screenrect, BLACK, 200, 210)
        drawtext(changed[1], 20, screenrect, BLACK, 200, 240)
        drawtext(changed[2], 20, screenrect, BLACK, 200, 270)
        drawtext(changed[3], 20, screenrect, BLACK, 200, 300)
        drawtext(changed[4], 20, screenrect, BLACK, 200, 330)
        drawtext(changed[5], 20, screenrect, BLACK, 200, 360)
        drawtext(response, 20, screenrect, BLACK, 200, 390)
        drawtext(tresponse, 20, screenrect, BLACK, 200, 420)
    button = 0

  display.flip()
  myClock.tick(60)
